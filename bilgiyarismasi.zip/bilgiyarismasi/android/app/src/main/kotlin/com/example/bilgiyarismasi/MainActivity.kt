package com.example.bilgiyarismasi

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
