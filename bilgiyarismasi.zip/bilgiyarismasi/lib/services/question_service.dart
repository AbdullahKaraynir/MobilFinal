import 'dart:convert';
import 'package:flutter/services.dart';
import 'dart:math';
import '../models/question_model.dart';

class QuestionService {
  static final Map<String, List<String>> dosyalar = {
    'easy': ['lib/assets/sorular/kolay1.json'],
    'medium': ['lib/assets/sorular/orta1.json'],
    'hard': ['lib/assets/sorular/zor1.json'],
  };

  static Future<List<Question>> loadQuestions(String difficulty) async {
    final random = Random();
    final files = dosyalar[difficulty];
    if (files == null || files.isEmpty)
      throw Exception("Geçersiz zorluk: $difficulty");

    final String file = files[random.nextInt(files.length)];
    final String content = await rootBundle.loadString(file);
    final List data = jsonDecode(content);
    return data.map((q) => Question.fromJson(q)).toList();
  }
}
