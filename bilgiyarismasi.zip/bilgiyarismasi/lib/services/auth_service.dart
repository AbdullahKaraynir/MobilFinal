import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:flutter_web_auth_2/flutter_web_auth_2.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:cloud_firestore/cloud_firestore.dart';

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // Kullanıcı durumu değişikliklerini dinle
  Stream<User?> get authStateChanges => _auth.authStateChanges();

  // E-posta ile Kayıt
  Future<String?> signUp(String email, String password) async {
    try {
      final userCredential = await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );

      // Create initial user document in Firestore
      try {
        await _firestore.collection('users').doc(userCredential.user!.uid).set({
          'email': email,
          'createdAt': FieldValue.serverTimestamp(),
        });
      } catch (e) {
        print('Firestore error during signup: $e');
        // Firestore hatası olsa bile kullanıcı kaydı başarılı sayılır
      }

      return null;
    } on FirebaseAuthException catch (e) {
      switch (e.code) {
        case 'weak-password':
          return 'Şifre çok zayıf.';
        case 'email-already-in-use':
          return 'Bu e-posta adresi zaten kullanımda.';
        case 'invalid-email':
          return 'Geçersiz e-posta adresi.';
        case 'operation-not-allowed':
          return 'E-posta/şifre girişi etkin değil.';
        default:
          return e.message ?? 'Bir hata oluştu.';
      }
    } catch (e) {
      print('Unexpected error during signup: $e');
      return 'Beklenmeyen bir hata oluştu.';
    }
  }

  // E-posta ile Giriş
  Future<String?> signIn(String email, String password) async {
    try {
      final userCredential = await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );

      // Kullanıcı dokümanını kontrol et
      try {
        final doc =
            await _firestore
                .collection('users')
                .doc(userCredential.user!.uid)
                .get();

        if (!doc.exists) {
          await _firestore
              .collection('users')
              .doc(userCredential.user!.uid)
              .set({'email': email, 'createdAt': FieldValue.serverTimestamp()});
        }
      } catch (e) {
        print('Firestore error during signin: $e');
        // Firestore hatası olsa bile giriş başarılı sayılır
      }

      return null;
    } on FirebaseAuthException catch (e) {
      switch (e.code) {
        case 'user-not-found':
          return 'Bu e-posta adresiyle kayıtlı kullanıcı bulunamadı.';
        case 'wrong-password':
          return 'Hatalı şifre.';
        case 'invalid-email':
          return 'Geçersiz e-posta adresi.';
        case 'user-disabled':
          return 'Bu hesap devre dışı bırakılmış.';
        case 'too-many-requests':
          return 'Çok fazla başarısız giriş denemesi. Lütfen daha sonra tekrar deneyin.';
        default:
          return e.message ?? 'Bir hata oluştu.';
      }
    } catch (e) {
      print('Unexpected error during signin: $e');
      return 'Beklenmeyen bir hata oluştu.';
    }
  }

  // Google ile Giriş
  Future<String?> signInWithGoogle() async {
    try {
      final GoogleSignIn googleSignIn = GoogleSignIn(
        clientId:
            '619943053254-66f446c2adcbf1e2b914c7.apps.googleusercontent.com',
        scopes: ['email', 'profile'],
      );

      final GoogleSignInAccount? googleUser = await googleSignIn.signIn();
      if (googleUser == null) return 'Google oturumu iptal edildi.';

      final GoogleSignInAuthentication googleAuth =
          await googleUser.authentication;

      final credential = GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken,
        idToken: googleAuth.idToken,
      );

      final userCredential = await _auth.signInWithCredential(credential);

      // Kullanıcı dokümanını kontrol et
      try {
        final doc =
            await _firestore
                .collection('users')
                .doc(userCredential.user!.uid)
                .get();

        if (!doc.exists) {
          await _firestore
              .collection('users')
              .doc(userCredential.user!.uid)
              .set({
                'email': userCredential.user!.email,
                'createdAt': FieldValue.serverTimestamp(),
              });
        }
      } catch (e) {
        print('Firestore error during Google signin: $e');
        // Firestore hatası olsa bile giriş başarılı sayılır
      }

      return null;
    } on FirebaseAuthException catch (e) {
      print(
        'Firebase Auth error during Google signin: ${e.code} - ${e.message}',
      );
      return 'Google ile giriş başarısız: ${e.message}';
    } catch (e) {
      print('Unexpected error during Google signin: $e');
      return 'Google ile giriş başarısız: $e';
    }
  }

  // GitHub ile Giriş (Firebase Console'da GitHub Auth etkinleştirilmeli)
  Future<String?> signInWithGitHub() async {
    try {
      const clientId = 'GITHUB_CLIENT_ID';
      const clientSecret = 'GITHUB_CLIENT_SECRET';
      const redirectUri = 'https://your-app.firebaseapp.com/__/auth/handler';

      final result = await FlutterWebAuth2.authenticate(
        url:
            'https://github.com/login/oauth/authorize?client_id=$clientId&redirect_uri=$redirectUri&scope=read:user,user:email',
        callbackUrlScheme: 'https',
      );

      final code = Uri.parse(result).queryParameters['code'];

      final response = await http.post(
        Uri.parse('https://github.com/login/oauth/access_token'),
        headers: {'Accept': 'application/json'},
        body: {
          'client_id': clientId,
          'client_secret': clientSecret,
          'code': code!,
        },
      );

      final accessToken = jsonDecode(response.body)['access_token'];

      final AuthCredential credential = GithubAuthProvider.credential(
        accessToken,
      );
      await _auth.signInWithCredential(credential);

      return null;
    } catch (e) {
      return 'GitHub ile giriş başarısız: $e';
    }
  }

  Future<void> signOut() async {
    try {
      await _auth.signOut();
    } catch (e) {
      print('Error during signout: $e');
      rethrow;
    }
  }

  User? get currentUser => _auth.currentUser;
}
