import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

// Ana renkler
const Color primaryColor = Color(0xFF6A1B9A); // Mor
const Color secondaryColor = Color(0xFFE91E63); // Pembe
const Color accentColor = Color(0xFFFFC107); // Altın
const Color backgroundColor = Color(0xFFF5F5F5); // Açık gri
const Color surfaceColor = Colors.white;
const Color errorColor = Color(0xFFD32F2F);

// Gradient renkler
const List<Color> primaryGradient = [
  Color(0xFF6A1B9A),
  Color(0xFF8E24AA),
  Color(0xFFAB47BC),
];

const List<Color> secondaryGradient = [
  Color(0xFFE91E63),
  Color(0xFFEC407A),
  Color(0xFFF06292),
];

// Text stilleri
TextStyle get headlineStyle => GoogleFonts.poppins(
      fontSize: 28,
      fontWeight: FontWeight.bold,
      color: Colors.white,
      shadows: [
        Shadow(
          offset: const Offset(1, 1),
          blurRadius: 3,
          color: Colors.black.withOpacity(0.3),
        ),
      ],
    );

TextStyle get titleStyle => GoogleFonts.poppins(
      fontSize: 24,
      fontWeight: FontWeight.w600,
      color: primaryColor,
    );

TextStyle get subtitleStyle => GoogleFonts.poppins(
      fontSize: 18,
      fontWeight: FontWeight.w500,
      color: secondaryColor,
    );

TextStyle get bodyStyle =>
    GoogleFonts.poppins(fontSize: 16, color: Colors.black87);

// Button stilleri
ButtonStyle get primaryButtonStyle => ElevatedButton.styleFrom(
      backgroundColor: primaryColor,
      foregroundColor: Colors.white,
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      elevation: 4,
      shadowColor: primaryColor.withOpacity(0.3),
    );

ButtonStyle get secondaryButtonStyle => ElevatedButton.styleFrom(
      backgroundColor: secondaryColor,
      foregroundColor: Colors.white,
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      elevation: 4,
      shadowColor: secondaryColor.withOpacity(0.3),
    );

// Input dekorasyon stilleri
InputDecorationTheme get inputDecorationTheme => InputDecorationTheme(
      filled: true,
      fillColor: Colors.white,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: primaryColor.withOpacity(0.5)),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: primaryColor.withOpacity(0.3)),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: primaryColor, width: 2),
      ),
      errorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: errorColor),
      ),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
    );

// AppBar teması
AppBarTheme get appBarTheme => AppBarTheme(
      backgroundColor: primaryColor,
      elevation: 0,
      centerTitle: true,
      titleTextStyle: GoogleFonts.poppins(
        fontSize: 20,
        fontWeight: FontWeight.w600,
        color: Colors.white,
      ),
      iconTheme: const IconThemeData(color: Colors.white),
    );

// Card teması
CardTheme get cardTheme => CardTheme(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      color: Colors.white,
      shadowColor: primaryColor.withOpacity(0.2),
    );

// Ana tema
ThemeData get quizTheme => ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.light(
        primary: primaryColor,
        secondary: secondaryColor,
        surface: surfaceColor,
        background: backgroundColor,
        error: errorColor,
      ),
      scaffoldBackgroundColor: backgroundColor,
      appBarTheme: appBarTheme,
      cardTheme: cardTheme,
      elevatedButtonTheme: ElevatedButtonThemeData(style: primaryButtonStyle),
      textTheme: TextTheme(
        displayLarge: headlineStyle,
        titleLarge: titleStyle,
        titleMedium: subtitleStyle,
        bodyLarge: bodyStyle,
      ),
      inputDecorationTheme: inputDecorationTheme,
    );
