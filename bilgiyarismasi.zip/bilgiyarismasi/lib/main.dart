import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';

import 'pages/login_page.dart';
import 'pages/register_page.dart';
import 'pages/menu_page.dart';
import 'pages/easy_quiz.dart';
import 'pages/medium_quiz.dart';
import 'pages/hard_quiz.dart';
import 'pages/result_page.dart';
import 'pages/settings_page.dart';
import 'theme.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  try {
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );

    // Firebase bağlantısını kontrol et
    if (Firebase.apps.isEmpty) {
      throw Exception('Firebase başlatılamadı');
    }

    print('Firebase başarıyla başlatıldı');
  } catch (e) {
    print('Firebase başlatma hatası: $e');
  }

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Bilgi Yarışması',
      theme: quizTheme,
      // Başlangıç sayfası login page
      initialRoute: '/',
      // Statik rotalar
      routes: {
        '/': (context) => const LoginPage(),
        '/register': (context) => const RegisterPage(),
        '/menu': (context) => const MenuPage(),
        '/easy': (context) => const EasyQuizPage(),
        '/medium': (context) => const MediumQuizPage(),
        '/hard': (context) => const HardQuizPage(),
        '/settings': (context) => const SettingsPage(),
      },
      // Dinamik route: Parametre alan sayfalar için
      onGenerateRoute: (settings) {
        if (settings.name == '/result') {
          final args = settings.arguments as Map<String, dynamic>?;

          final int skor =
              args != null && args['skor'] != null ? args['skor'] as int : 0;
          final int totalQuestions =
              args != null && args['totalQuestions'] != null
                  ? args['totalQuestions'] as int
                  : 0;
          final String difficulty = args != null && args['difficulty'] != null
              ? args['difficulty'] as String
              : 'easy';

          return MaterialPageRoute(
            builder: (context) => ResultPage(
              skor: skor,
              totalQuestions: totalQuestions,
              difficulty: difficulty,
            ),
          );
        }
        // Tanımlanmayan route için null dön
        return null;
      },
    );
  }
}
