import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:bilgiyarismasi/custom_app_bar.dart';
import '../services/auth_service.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final AuthService _authService = AuthService();

  bool _isLoading = false;
  String? _errorMessage;

  Future<void> _kullaniciYonlendir() async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) {
        setState(() {
          _errorMessage = 'Oturum açık değil. Lütfen tekrar giriş yapın.';
        });
        return;
      }

      // Başarılı giriş durumunda direkt menüye yönlendir
      if (mounted) {
        Navigator.pushReplacementNamed(context, '/menu');
      }
    } catch (e) {
      print('Yönlendirme hatası: $e');
      setState(() {
        _errorMessage =
            'Yönlendirme sırasında bir hata oluştu. Lütfen tekrar deneyin.';
      });
    }
  }

  void _girisYap() async {
    final email = _emailController.text.trim();
    final sifre = _passwordController.text.trim();

    if (email.isEmpty || sifre.isEmpty) {
      setState(() {
        _errorMessage = 'Lütfen e-posta ve şifrenizi girin.';
      });
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      // Firebase bağlantısını kontrol et
      if (!FirebaseAuth.instance.app.options.projectId.isNotEmpty) {
        throw Exception('Firebase bağlantısı kurulamadı.');
      }

      final error = await _authService.signIn(email, sifre);

      if (error != null) {
        setState(() {
          _isLoading = false;
          _errorMessage = error;
        });
        return;
      }

      // Giriş başarılı olduğunda kullanıcıyı bilgilendir
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Giriş başarılı! Yönlendiriliyorsunuz...'),
            backgroundColor: Colors.green,
          ),
        );
      }

      await _kullaniciYonlendir();
    } catch (e) {
      setState(() {
        _isLoading = false;
        _errorMessage = 'Giriş yapılırken bir hata oluştu: $e';
      });

      // Hata detaylarını konsola yazdır
      print('Login error: $e');
    }
  }

  void _girisYapGoogle() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      final error = await _authService.signInWithGoogle();

      if (error != null) {
        setState(() {
          _isLoading = false;
          _errorMessage = error;
        });
        return;
      }

      await _kullaniciYonlendir();
    } catch (e) {
      setState(() {
        _isLoading = false;
        _errorMessage = 'Google ile giriş yapılırken bir hata oluştu: $e';
      });
    }
  }

  void _girisYapGitHub() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    final error = await _authService.signInWithGitHub();

    setState(() {
      _isLoading = false;
      _errorMessage = error;
    });

    if (error == null) {
      _kullaniciYonlendir();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const CustomAppBar(title: 'Giriş Yap'),
      body: Container(
        decoration: const BoxDecoration(
          gradient: RadialGradient(
            colors: [
              Color.fromARGB(255, 170, 36, 70),
              Color.fromARGB(255, 210, 21, 144),
            ],
            center: Alignment.center,
            radius: 1.0,
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Center(
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextField(
                    controller: _emailController,
                    decoration: const InputDecoration(
                      labelText: 'E-posta',
                      prefixIcon: Icon(Icons.email),
                    ),
                    keyboardType: TextInputType.emailAddress,
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _passwordController,
                    decoration: const InputDecoration(
                      labelText: 'Şifre',
                      prefixIcon: Icon(Icons.lock),
                    ),
                    obscureText: true,
                  ),
                  const SizedBox(height: 24),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: _isLoading ? null : _girisYap,
                      child:
                          _isLoading
                              ? const SizedBox(
                                height: 20,
                                width: 20,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  color: Colors.white,
                                ),
                              )
                              : const Text('Giriş Yap'),
                    ),
                  ),
                  const SizedBox(height: 16),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      icon: const Icon(
                        Icons.g_mobiledata,
                        color: Colors.redAccent,
                      ),
                      label: const Text('Google ile Giriş Yap'),
                      onPressed: _isLoading ? null : _girisYapGoogle,
                    ),
                  ),
                  const SizedBox(height: 12),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      icon: const Icon(Icons.code, color: Colors.black),
                      label: const Text('GitHub ile Giriş Yap'),
                      onPressed: _isLoading ? null : _girisYapGitHub,
                    ),
                  ),
                  const SizedBox(height: 16),
                  if (_errorMessage != null)
                    Text(
                      _errorMessage!,
                      style: const TextStyle(color: Colors.white),
                      textAlign: TextAlign.center,
                    ),
                  const SizedBox(height: 24),
                  TextButton(
                    onPressed: () {
                      Navigator.pushNamed(context, '/register');
                    },
                    child: const Text('Hesabın yok mu? Kayıt ol'),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
