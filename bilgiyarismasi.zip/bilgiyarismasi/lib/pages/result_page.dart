import 'package:flutter/material.dart';
import '../drawer_widget.dart';

class ResultPage extends StatelessWidget {
  final int skor;
  final int totalQuestions;
  final String difficulty;

  const ResultPage({
    super.key,
    required this.skor,
    required this.totalQuestions,
    required this.difficulty,
  });

  String getYorum() {
    final percentage = (skor / totalQuestions) * 100;
    if (percentage >= 90) return "Harikasın! 🚀";
    if (percentage >= 70) return "Çok iyi iş çıkardın! 🎯";
    if (percentage >= 50) return "Fena değil, biraz daha çalış 💪";
    return "Daha çok çalışmalısın! 📚";
  }

  String getDifficultyText() {
    switch (difficulty) {
      case 'easy':
        return 'Kolay';
      case 'medium':
        return 'Orta';
      case 'hard':
        return 'Zor';
      default:
        return '';
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(
        title: const Text('Sonuç'),
        backgroundColor: const Color.fromARGB(255, 170, 36, 70),
      ),
      drawer: const DrawerMenu(),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                '${getDifficultyText()} Quiz Tamamlandı!',
                style: theme.textTheme.headlineMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 20),
              Icon(Icons.emoji_events, size: 72, color: Colors.amber.shade700),
              const SizedBox(height: 20),
              Text(
                'Toplam Skor: $skor/$totalQuestions',
                style: theme.textTheme.displaySmall?.copyWith(
                  color: Colors.green.shade700,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 16),
              Text(
                getYorum(),
                style: theme.textTheme.titleLarge?.copyWith(
                  fontStyle: FontStyle.italic,
                  color: theme.colorScheme.primary,
                ),
              ),
              const SizedBox(height: 40),
              ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 24,
                    vertical: 12,
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                  textStyle: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                icon: const Icon(Icons.home),
                label: const Text("Ana Menüye Dön"),
                onPressed: () {
                  Navigator.pushNamedAndRemoveUntil(
                    context,
                    '/menu',
                    (route) => false,
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
