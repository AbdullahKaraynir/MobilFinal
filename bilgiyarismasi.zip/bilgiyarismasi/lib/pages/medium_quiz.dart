import 'dart:async';
import 'package:flutter/material.dart';
import 'package:audioplayers/audioplayers.dart';
import '../drawer_widget.dart';
import '../services/question_service.dart';
import '../models/question_model.dart';
import 'result_page.dart';
import 'package:bilgiyarismasi/custom_app_bar.dart';

class MediumQuizPage extends StatefulWidget {
  const MediumQuizPage({super.key});

  @override
  State<MediumQuizPage> createState() => _MediumQuizPageState();
}

class _MediumQuizPageState extends State<MediumQuizPage> {
  List<Question> _questions = [];
  int _currentQuestionIndex = 0;
  int _score = 0;
  bool _isLoading = true;
  Timer? _timer;
  int _timeLeft = 20;
  final AudioPlayer _audioPlayer = AudioPlayer();
  bool _isAnswerSelected = false;

  @override
  void initState() {
    super.initState();
    _loadQuestions();
    _loadSounds();
  }

  Future<void> _loadSounds() async {
    await _audioPlayer.setSource(AssetSource('sounds/tick.mp3'));
  }

  void _startTimer() {
    _timeLeft = 20;
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      setState(() {
        if (_timeLeft > 0) {
          _timeLeft--;
          if (_timeLeft <= 5) {
            _audioPlayer.play(AssetSource('sounds/tick.mp3'));
          }
        } else {
          _timer?.cancel();
          if (!_isAnswerSelected) {
            _moveToNextQuestion();
          }
        }
      });
    });
  }

  void _stopTimer() {
    _timer?.cancel();
    _timer = null;
  }

  Future<void> _loadQuestions() async {
    try {
      final questions = await QuestionService.loadQuestions('medium');
      setState(() {
        _questions = questions;
        _isLoading = false;
      });
      _startTimer();
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Soru yüklenirken hata oluştu: $e')),
        );
      }
    }
  }

  void _moveToNextQuestion() {
    if (_currentQuestionIndex < _questions.length - 1) {
      setState(() {
        _currentQuestionIndex++;
        _isAnswerSelected = false;
      });
      _startTimer();
    } else {
      _stopTimer();
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => ResultPage(
            skor: _score,
            totalQuestions: _questions.length,
            difficulty: 'medium',
          ),
        ),
      );
    }
  }

  void _answerQuestion(String answer) {
    if (_isAnswerSelected) return;

    _isAnswerSelected = true;
    _stopTimer();

    if (_currentQuestionIndex < _questions.length) {
      final currentQuestion = _questions[_currentQuestionIndex];
      if (answer == currentQuestion.correctAnswer) {
        _score++;
        _audioPlayer.play(AssetSource('sounds/correct.mp3'));
      } else {
        _audioPlayer.play(AssetSource('sounds/wrong.mp3'));
      }

      Future.delayed(const Duration(seconds: 1), () {
        if (mounted) {
          _moveToNextQuestion();
        }
      });
    }
  }

  @override
  void dispose() {
    _stopTimer();
    _audioPlayer.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    if (_questions.isEmpty) {
      return Scaffold(
        appBar: AppBar(
          title: const Text('Orta Quiz'),
          backgroundColor: const Color.fromARGB(255, 170, 36, 70),
        ),
        drawer: const DrawerMenu(),
        body: const Center(child: Text('Soru bulunamadı')),
      );
    }

    final currentQuestion = _questions[_currentQuestionIndex];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Orta Quiz'),
        backgroundColor: const Color.fromARGB(255, 170, 36, 70),
      ),
      drawer: const DrawerMenu(),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Soru ${_currentQuestionIndex + 1}/${_questions.length}',
                  style: const TextStyle(fontSize: 18),
                ),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: _timeLeft <= 5 ? Colors.red : Colors.green,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    '$_timeLeft saniye',
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
            Text(
              currentQuestion.question,
              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 40),
            ...currentQuestion.options.map(
              (option) => Padding(
                padding: const EdgeInsets.symmetric(vertical: 8.0),
                child: ElevatedButton(
                  onPressed:
                      _isAnswerSelected ? null : () => _answerQuestion(option),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _isAnswerSelected
                        ? option == currentQuestion.correctAnswer
                            ? Colors.green
                            : option == currentQuestion.correctAnswer
                                ? Colors.red
                                : null
                        : null,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                  ),
                  child: Text(option),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
